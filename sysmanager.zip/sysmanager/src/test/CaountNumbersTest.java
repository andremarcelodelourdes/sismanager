package test;

import static org.junit.Assert.fail;

import org.junit.Test;

public class CaountNumbersTest {

	@Test
	public void test() {
		int lessers = CountNumber.countNumbers(new int[] {1,3,5,7}, 4);
		System.out.println(lessers + " menor(es)");
		if(lessers != 2){
			fail("Problem!!");			
		}
		
	}

}
