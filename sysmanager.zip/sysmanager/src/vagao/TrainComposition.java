package vagao;

import java.util.Deque;
import java.util.LinkedList;

public class TrainComposition {

private final Deque<Integer> vagaos = new LinkedList<>();

public void atracaEsquerda(int numeroVagao) {

vagaos.addFirst(numeroVagao);

}

public void atracaDireita(int numeroVagao) {

vagaos.addLast(numeroVagao);

}

public void desatracaEsquerda() {

if (!vagaos.isEmpty()) {

vagaos.removeFirst(); 
} else {

throw new IndexOutOfBoundsException("Nenhum vagao dispon�vel");

}

}

public void desatracaDireita() {

if (!vagaos.isEmpty()) {

vagaos.removeLast(); 
} else {

throw new IndexOutOfBoundsException("Nenhum vagao dispon�vel");

}

}

public static void main(String[] args) {
TrainComposition trem= new TrainComposition();
for (int i=0; i<15; i++) {
trem.atracaEsquerda(i);
}
System.out.println(trem.vagaos);
trem.atracaDireita(30);
System.out.println(trem.vagaos);

}

}
